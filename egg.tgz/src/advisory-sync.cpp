// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("advisory sync\n", stdout);
  return lionss_run_workload("advisory-sync");
}
