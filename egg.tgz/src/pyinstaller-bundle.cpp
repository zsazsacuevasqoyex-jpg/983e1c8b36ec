// GEN-TOOL
#include "workload.h"
#include <cstdio>
int main(){
  std::fputs("pyinstaller bundle\n", stdout);
  return lionss_run_workload("pyinstaller-bundle");
}
